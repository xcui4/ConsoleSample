
namespace postage_calculator.Item
{
    public interface IPostable
    {
        double Postage();
    }
}